<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Crypto;
use App\Models\Currency;
use App\Models\UserWallet;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // Get all supported cryptos
        $cryptos = Currency::all();

        // Attach user balance to each crypto
        foreach ($cryptos as $crypto) {
            $wallet = UserWallet::where('user_id', $user->id)
                ->where('currency', $crypto->symbol)
                ->first();
            $crypto->user_balance = $wallet ? $wallet->balance : 0;
        }

        // Pass to view
        return view('templates.basic.user.dashboard', compact('cryptos'));
    }
}
?>
