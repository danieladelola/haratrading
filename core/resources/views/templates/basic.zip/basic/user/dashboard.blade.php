@extends($activeTemplate . 'layouts.master2')
@php
    $kyc = getContent('kyc.content', true);
@endphp

<style>
    :root {
        --primary: #6c5ce7;
        --primary-dark: #5649c0;
        --secondary: #3f37c9;
        --success: #00b894;
        --danger: #d63031;
        --warning: #fdcb6e;
        --info: #0984e3;
        --light: #2d3436;
        --dark: #1e272e;
        --gray: #636e72;
        --gray-light: #2d3436;
        --white: #ffffff;
        --card-bg: #1e272e;
        --card-border: #2d3436;
        --text-primary: #f5f6fa;
        --text-secondary: #dfe6e9;
    }

    /* Base Styles */
    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        background-color: #12181b;
        color: var(--text-primary);
        line-height: 1.6;
    }

    /* Card Styles */
    .dashboard-card {
        background: var(--card-bg);
        border-radius: 12px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border: 1px solid var(--card-border);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .dashboard-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
    }

    .card-header {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid var(--card-border);
    }

    .card-body {
        padding: 1.5rem;
        color: var(--text-secondary);
    }

    /* Typography */
    .text-heading {
        font-weight: 600;
        color: var(--text-primary);
    }

    .text-subheading {
        font-weight: 500;
        color: var(--gray);
        font-size: 0.875rem;
    }

    /* Tab Styles */
    .tab-nav {
        display: flex;
        border-bottom: 1px solid var(--card-border);
    }

    .tab-nav-item {
        padding: 0.75rem 1rem;
        font-weight: 500;
        color: var(--gray);
        cursor: pointer;
        position: relative;
        transition: all 0.2s ease;
    }

    .tab-nav-item:hover {
        color: var(--primary);
    }

    .tab-nav-item.active {
        color: var(--primary);
    }

    .tab-nav-item.active::after {
        content: '';
        position: absolute;
        bottom: -1px;
        left: 0;
        right: 0;
        height: 2px;
        background-color: var(--primary);
    }

    .tab-content {
        display: none;
    }

    .tab-content.active {
        display: block;
    }

    /* Button Styles */
    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem 1rem;
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.2s ease;
        border: none;
        cursor: pointer;
    }

    .btn-primary {
        background-color: var(--primary);
        color: var(--white);
    }

    .btn-primary:hover {
        background-color: var(--primary-dark);
        transform: translateY(-1px);
    }

    .btn-success {
        background-color: var(--success);
        color: var(--white);
    }

    .btn-success:hover {
        background-color: #00a383;
    }

    .btn-danger {
        background-color: var(--danger);
        color: var(--white);
    }

    .btn-danger:hover {
        background-color: #c0392b;
    }

    .btn-outline {
        background-color: transparent;
        border: 1px solid var(--gray-light);
        color: var(--gray);
    }

    .btn-outline:hover {
        background-color: var(--gray-light);
    }

    /* Form Styles */
    .form-control {
        width: 100%;
        padding: 0.625rem 0.875rem;
        border: 1px solid var(--card-border);
        border-radius: 8px;
        transition: all 0.2s ease;
        background-color: var(--white);
        color: #000000;
    }

    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px rgba(108, 92, 231, 0.15);
        outline: none;
    }

    .form-label {
        display: block;
        margin-bottom: 0.5rem;
        font-weight: 500;
        color: var(--text-primary);
        font-size: 0.875rem;
    }

    /* Table Styles */
    .data-table {
        width: 100%;
        border-collapse: collapse;
        border-radius: 8px;
        overflow: hidden;
    }

    .data-table th {
        background-color: var(--dark);
        color: var(--gray);
        font-weight: 600;
        text-align: left;
        padding: 0.75rem 1rem;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .data-table td {
        padding: 1rem;
        border-bottom: 1px solid var(--card-border);
        vertical-align: middle;
        color: var(--text-secondary);
    }

    .data-table tr:last-child td {
        border-bottom: none;
    }

    .data-table tr:hover {
        background-color: var(--dark);
    }

    /* Badge Styles */
    .badge {
        display: inline-flex;
        align-items: center;
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .badge-success {
        background-color: rgba(0, 184, 148, 0.2);
        color: var(--success);
    }

    .badge-danger {
        background-color: rgba(214, 48, 49, 0.2);
        color: var(--danger);
    }

    .badge-warning {
        background-color: rgba(253, 203, 110, 0.2);
        color: var(--warning);
    }

    .badge-info {
        background-color: rgba(9, 132, 227, 0.2);
        color: var(--info);
    }

    /* Progress Bars */
    .progress-container {
        height: 8px;
        border-radius: 4px;
        background-color: var(--dark);
        overflow: hidden;
    }

    .progress-bar {
        height: 100%;
        border-radius: 4px;
        transition: width 0.6s ease;
    }

    /* Crypto Icons */
    .crypto-icon {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-right: 12px;
        background-color: var(--dark);
        overflow: hidden;
    }

    /* Modal Styles */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
    }

    .modal-overlay.active {
        opacity: 1;
        visibility: visible;
    }

    .modal-content {
        background-color: var(--card-bg);
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        width: 100%;
        max-width: 500px;
        transform: translateY(20px);
        transition: all 0.3s ease;
        border: 1px solid var(--card-border);
    }

    .modal-overlay.active .modal-content {
        transform: translateY(0);
    }

    .modal-header {
        padding: 1.25rem 1.5rem;
        border-bottom: 1px solid var(--card-border);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-body {
        padding: 1.5rem;
    }

    .modal-close {
        color: var(--gray);
        font-size: 1.5rem;
        cursor: pointer;
        transition: color 0.2s ease;
    }

    .modal-close:hover {
        color: var(--text-primary);
    }

    /* Signal Bars */
    .signal-bars {
        display: flex;
        gap: 4px;
        height: 8px;
    }

    .signal-bar {
        flex: 1;
        border-radius: 2px;
        transition: all 0.3s ease;
    }

    /* Empty State */
    .empty-state {
        text-align: center;
        padding: 2rem;
    }

    .empty-state-icon {
        font-size: 3rem;
        color: var(--gray-light);
        margin-bottom: 1rem;
    }

    .empty-state-text {
        color: var(--gray);
        margin-bottom: 1.5rem;
    }

    /* Responsive Grid */
    .grid-container {
        display: grid;
        gap: 1.5rem;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }

    /* Animations */
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    .animate-fade {
        animation: fadeIn 0.3s ease-out;
    }

    /* Utility Classes */
    .text-success {
        color: var(--success);
    }

    .text-danger {
        color: var(--danger);
    }

    .text-warning {
        color: var(--warning);
    }

    .bg-success-light {
        background-color: rgba(0, 184, 148, 0.1);
    }

    .bg-danger-light {
        background-color: rgba(214, 48, 49, 0.1);
    }

    .bg-warning-light {
        background-color: rgba(253, 203, 110, 0.1);
    }

    .bg-info-light {
        background-color: rgba(9, 132, 227, 0.1);
    }

    /* Trading View Widget */
    .tradingview-widget-container {
        height: 100%;
        width: 100%;
        border-radius: 8px;
        overflow: hidden;
    }

    /* Custom Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }

    ::-webkit-scrollbar-track {
        background: var(--dark);
    }

    ::-webkit-scrollbar-thumb {
        background: var(--gray);
        border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--gray-light);
    }

    /* Hover effects for crypto items */
    .crypto-item:hover {
        background-color: var(--dark);
    }

    /* KYC status boxes */
    .kyc-status {
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
    }

    /* Gradient text for headings */
    .gradient-text {
        background: linear-gradient(90deg, var(--primary), var(--info));
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
    }

    /* Divider style */
    .divider {
        height: 1px;
        background-color: var(--card-border);
        margin: 1rem 0;
    }

    /* Input group style */
    .input-group {
        display: flex;
        border: 1px solid var(--card-border);
        border-radius: 8px;
        overflow: hidden;
    }

    .input-group input {
        flex: 1;
        border: none;
        background: var(--dark);
        color: var(--text-primary);
        padding: 0.625rem 0.875rem;
    }

    .input-group .input-addon {
        background: var(--dark);
        color: var(--gray);
        padding: 0.625rem 0.875rem;
        display: flex;
        align-items: center;
    }

    /* Dropdown menu style */
    .dropdown-menu {
        background: var(--card-bg);
        border: 1px solid var(--card-border);
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Active tab button style */
    .active-tab-btn {
        background-color: var(--primary) !important;
        color: white !important;
    }

    /* Inactive tab button style */
    .inactive-tab-btn {
        background-color: var(--dark) !important;
        color: var(--gray) !important;
    }

    /* Notification badge */
    .notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        background-color: var(--danger);
        color: white;
        border-radius: 50%;
        width: 18px;
        height: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
    }

    /* Balance Display */
    .balance-display {
        background: linear-gradient(135deg, var(--primary), var(--info));
        border-radius: 12px;
        padding: 1rem;
        color: var(--white);
        margin-bottom: 1rem;
    }
</style>

@section('content')
<div class="container mx-auto px-4 py-6">
    <!-- Dashboard Header -->
    <div class="mb-6">
        <h1 class="text-2xl font-bold gradient-text">Dashboard Overview</h1>
        <p class="text-gray-500">Welcome back, {{ auth()->user()->username }}</p>
    </div>

    <!-- Balance and Stats Cards -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <!-- Balance Card -->
        <div class="dashboard-card">
            <div class="card-header">
                <div class="flex justify-between items-center">
                    <div>
                        <h3 class="text-subheading">Total Balance</h3>
                        <p class="text-heading text-2xl">{{ showAmount(auth()->user()->balance) }}</p>
                    </div>
                    <div class="flex space-x-2">
                        <button class="p-2 rounded-lg tab-nav-item active" data-tab="tab1">
                            <i class="ri-file-list-line"></i>
                        </button>
                        <button class="p-2 rounded-lg tab-nav-item" data-tab="tab2">
                            <i class="ri-smartphone-line"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div id="tab1" class="tab-content active animate-fade">
                    <h4 class="text-subheading mb-3">Recent Deposits</h4>
                    <div class="space-y-3">
                        @foreach($Topcurrencies as $currency)
                            @php
                                $symbollowcase = strtolower($currency->currency);
                                $apiUrl = "https://min-api.cryptocompare.com/data/price?fsym={$currency->currency}&tsyms=USD";
                                $response = file_get_contents($apiUrl);
                                $data = json_decode($response, true);
                                $rate = $data['USD'] ?? 0;
                                $amount_usd = $currency->amount * $rate;
                            @endphp

                            <div class="flex items-center justify-between p-3 hover:bg-gray-800 rounded-lg transition-colors crypto-item">
                                <div class="flex items-center">
                                    <div class="crypto-icon">
                                        <img src="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/refs/heads/master/svg/color/{{ $symbollowcase }}.svg"
                                             class="w-4 h-4"
                                             onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/0/381.png'">
                                    </div>
                                    <div>
                                        <div class="text-heading">{{ $currency->currency }}</div>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-heading">${{ number_format($amount_usd, 2) }}</div>
                                    <div class="text-subheading">{{ $currency->amount }} {{ $currency->currency }}</div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div id="tab2" class="tab-content animate-fade">
                    <div class="space-y-4">
                        <div class="flex justify-between items-center py-3 border-b border-gray-700">
                            <div class="flex items-center">
                                <i class="ri-currency-line text-gray-500 mr-2"></i>
                                <span class="text-subheading">Total Deposits</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <p class="text-heading">{{ showAmount(auth()->user()->balance) }}</p>
                                <a href="{{ route('crypto.deposit.index') }}" class="btn btn-primary text-sm">Deposit</a>
                            </div>
                        </div>

                        <div class="flex justify-between items-center py-3 border-b border-gray-700">
                            <div class="flex items-center">
                                <i class="ri-currency-line text-gray-500 mr-2"></i>
                                <span class="text-subheading">Total Withdrawals</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <p class="text-heading">{{ showAmount($totalWithdraw) }}</p>
                                <a href="{{ route('user.withdraw') }}" class="btn btn-primary text-sm">Withdraw</a>
                            </div>
                        </div>

                        <div class="flex justify-between items-center py-3 border-b border-gray-700">
                            <div class="flex items-center">
                                <i class="ri-currency-line text-gray-500 mr-2"></i>
                                <span class="text-subheading">Total Profits</span>
                            </div>
                            <p class="text-heading">$0.00</p>
                        </div>

                        <div class="flex justify-between items-center py-3">
                            <div class="flex items-center">
                                <i class="ri-shield-check-line text-gray-500 mr-2"></i>
                                <span class="text-subheading">Verification</span>
                            </div>
                            @if (auth()->user()->kv == Status::KYC_UNVERIFIED && auth()->user()->kyc_rejection_reason)
                                <div class="kyc-status bg-danger-light text-danger">
                                    <div class="flex justify-between items-center">
                                        <h4 class="font-bold">@lang('KYC Documents Rejected')</h4>
                                    </div>
                                    <hr class="my-2 border-gray-700">
                                    <p class="mb-0">
                                        {{ __(@$kyc->data_values->reject) }}
                                        <a href="javascript::void(0)" class="text-primary underline" data-bs-toggle="modal" data-bs-target="#kycRejectionReason">@lang('Click here')</a>
                                        @lang('to show the reason').
                                        <a href="{{ route('user.kyc.form') }}" class="text-primary underline">@lang('Click Here')</a>
                                        @lang('to Re-submit Documents').
                                        <a class="text-primary underline" href="{{ route('user.kyc.data') }}">@lang('See KYC Data')</a>
                                    </p>
                                </div>
                            @elseif(auth()->user()->kv == Status::KYC_UNVERIFIED)
                                <div class="kyc-status bg-warning-light text-warning">
                                    <h4 class="font-bold">@lang('KYC Verification Required')</h4>
                                    <hr class="my-2 border-gray-700">
                                    <p class="mb-0">
                                        {{ __(@$kyc->data_values->required) }}
                                        <a class="text-primary underline" href="{{ route('user.kyc.form') }}">@lang('Click Here to Submit Documents')</a>
                                    </p>
                                </div>
                            @elseif(auth()->user()->kv == Status::KYC_PENDING)
                                <div class="kyc-status bg-info-light text-info">
                                    <h4 class="font-bold">@lang('KYC Verification Pending')</h4>
                                    <hr class="my-2 border-gray-700">
                                    <p class="mb-0">
                                        {{ __(@$kyc->data_values->pending) }}
                                        <a class="text-primary underline" href="{{ route('user.kyc.data') }}">@lang('See KYC Data')</a>
                                    </p>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Trading Performance Card -->
        <div class="dashboard-card">
            <div class="card-body space-y-6">
                <!-- Trading Progress Card -->
                <div>
                    <h3 class="text-subheading mb-3">Trading Performance</h3>
                    @php
                        $completedTrades = $userAssets->where('status', 'complete')->count();
                        $totalTrades = $userAssets->count();
                        $progressPercent = $totalTrades > 0 ? ($completedTrades / $totalTrades) * 100 : 0;
                    @endphp
                    <div class="progress-container">
                        <div class="progress-bar bg-success" style="width: {{ $progressPercent }}%"></div>
                    </div>
                    <div class="flex justify-between mt-1">
                        <span class="text-subheading text-xs">{{ $completedTrades }} completed</span>
                        <span class="text-subheading text-xs">{{ $totalTrades }} total</span>
                    </div>
                </div>

                <!-- Signal Strength Card -->
                <div>
                    <h3 class="text-subheading mb-3">Market Signal Strength</h3>
                    @php
                        $signalStrength = 10; // This should be dynamic in your actual implementation
                        $barCount = 5;
                        $activeBarCount = ceil(($signalStrength / 100) * $barCount);
                    @endphp
                    <div class="signal-bars" id="signal-bars">
                        @for ($i = 1; $i <= $barCount; $i++)
                            @if ($i <= $activeBarCount)
                                <div class="signal-bar"
                                    style="background-color: {{ $i <= 1 ? 'var(--danger)' : ($i <= 3 ? 'var(--warning)' : 'var(--success)') }};"></div>
                            @else
                                <div class="signal-bar bg-gray-700"></div>
                            @endif
                        @endfor
                    </div>
                    <div class="flex justify-between mt-1">
                        <span class="text-subheading text-xs">Low</span>
                        <span class="text-xs font-medium signal-strength-value {{ $signalStrength > 50 ? 'text-success' : 'text-danger' }}">
                            {{ $signalStrength }}%
                        </span>
                        <span class="text-subheading text-xs">High</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Chart and Trading Section -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <!-- Market Chart Section - Enhanced -->
        <div class="lg:col-span-2">
            <div class="dashboard-card h-full">
                <div class="card-header">
                    <div class="flex justify-between items-center">
                        <h3 class="text-heading">Market Chart</h3>
                        <div class="flex space-x-2">
                            <button class="chart-type-btn active" data-type="crypto" onclick="switchChartType('crypto')">
                                <i class="ri-currency-line mr-1"></i> Crypto
                            </button>
                            <button class="chart-type-btn" data-type="stock" onclick="switchChartType('stock')">
                                <i class="ri-line-chart-line mr-1"></i> Stock
                            </button>
                            <button class="chart-type-btn" data-type="forex" onclick="switchChartType('forex')">
                                <i class="ri-exchange-line mr-1"></i> Forex
                            </button>
                        </div>
                    </div>
                </div>
                <div class="card-body p-0 h-[400px]">
                    <!-- TradingView Widget for Crypto -->
                    <div id="crypto-chart" class="tradingview-widget-container chart-container active">
                        <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%"></div>
                        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
                            {
                                "height": "400",
                                "symbol": "BINANCE:BTCUSDT",
                                "interval": "D",
                                "timezone": "Etc/UTC",
                                "theme": "dark",
                                "style": "1",
                                "locale": "en",
                                "hide_top_toolbar": false,
                                "allow_symbol_change": true,
                                "calendar": false,
                                "support_host": "https://www.tradingview.com"
                            }
                        </script>
                    </div>

                    <!-- TradingView Widget for Stocks -->
                    <div id="stock-chart" class="tradingview-widget-container chart-container">
                        <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%"></div>
                        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
                            {
                                "height": "400",
                                "symbol": "NASDAQ:AAPL",
                                "interval": "D",
                                "timezone": "Etc/UTC",
                                "theme": "dark",
                                "style": "1",
                                "locale": "en",
                                "hide_top_toolbar": false,
                                "allow_symbol_change": true,
                                "calendar": false,
                                "support_host": "https://www.tradingview.com"
                            }
                        </script>
                    </div>

                    <!-- TradingView Widget for Forex -->
                    <div id="forex-chart" class="tradingview-widget-container chart-container">
                        <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%"></div>
                        <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
                            {
                                "height": "400",
                                "symbol": "FX:EURUSD",
                                "interval": "D",
                                "timezone": "Etc/UTC",
                                "theme": "dark",
                                "style": "1",
                                "locale": "en",
                                "hide_top_toolbar": false,
                                "allow_symbol_change": true,
                                "calendar": false,
                                "support_host": "https://www.tradingview.com"
                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>

        <!-- Enhanced Trading Panel -->
        <div class="dashboard-card">
            <div class="card-header">
                <h3 class="text-heading">New Trade</h3>
            </div>
            <div class="card-body">
                <form action="{{ route('user.trade.store') }}" method="post" id="tradeForm">
                    @csrf
                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <!-- Buy Button -->
                        <button type="button" onclick="openModal('buyCryptoModal')"
                                class="btn btn-success w-full text-center">
                            Buy Crypto
                        </button>

                        <!-- Sell Button -->
                        <button type="button" onclick="openModal('sellCryptoModal')"
                                class="btn btn-danger w-full text-center">
                            Sell Crypto
                        </button>

                        <!-- Fiat to Coin Button -->
                        <button type="button" onclick="openModal('fiatToCryptoModal')"
                                class="btn btn-primary w-full text-center">
                            Fiat to Coin
                        </button>

                        <!-- Coin to Fiat Button -->
                        <button type="button" onclick="openModal('cryptoToFiatModal')"
                                class="btn btn-info w-full text-center">
                            Coin to Fiat
                        </button>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label class="form-label">Trade Type:</label>
                            <select class="form-control" name="trade_type" id="assetType" onchange="updateAssetDropdown()">
                                <option value="crypto">Crypto</option>
                                <option value="stock">Stock</option>
                                <option value="fiat">Fiat</option>
                            </select>
                        </div>

                        <div>
                            <label class="form-label">Asset:</label>
                            <div class="relative">
                                <div class="flex items-center border border-gray-700 rounded-lg bg-gray-800 text-gray-100 px-3 py-2">
                                    <input id="amount" type="text" name="amount" placeholder="100" class="flex-1 bg-transparent outline-none text-gray-100 placeholder-gray-500" />
                                    <div class="relative ml-2">
                                        <button id="dropdownButton" type="button" class="flex items-center justify-center space-x-2 text-sm bg-gray-700 px-3 py-1.5 rounded-lg hover:bg-gray-600">
                                            <img id="selectedIcon" src="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/refs/heads/master/svg/color/btc.svg" alt="BTC" class="w-4 h-4" />
                                            <span id="selectedSymbol" class="text-gray-100">BTC</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-4 h-4 ml-1 text-gray-400">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                                            </svg>
                                        </button>
                                        <div id="dropdownMenu" class="absolute z-10 hidden mt-1 w-64 bg-gray-800 border border-gray-700 rounded-lg shadow-lg left-0 md:left-auto md:right-0 overflow-auto max-h-60">
                                            <div class="p-2 border-b border-gray-700">
                                                <input type="text" id="assetSearch" placeholder="Search for assets" class="w-full px-3 py-2 text-sm bg-gray-700 text-gray-100 rounded-lg border border-gray-600 placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:outline-none" />
                                            </div>
                                            <ul class="max-h-52 overflow-y-auto text-sm" id="assetList">
                                                {{-- Assets will be loaded here by javascript --}}
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" name="assets" id="selectedAssetSymbol" value="BTC" />
                            </div>
                        </div>

                        <!-- Balance Display -->
                        <div class="balance-display">
                            <div class="flex justify-between items-center">
                                <div>
                                    <span class="text-sm opacity-90">Current USD Balance:</span>
                                    <div class="text-lg font-bold">{{ showAmount(auth()->user()->balance) }}</div>
                                </div>
                                <div>
                                    <span class="text-sm opacity-90">Asset Balance:</span>
                                    <div class="text-lg font-bold" id="assetBalance">0.00</div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label class="text-subheading">Current Asset Price: <span id="currentAssetPrice" class="text-heading">$0.00</span></label>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="form-label">Stop Loss:</label>
                                <input type="number" name="loss" value="6800" class="form-control">
                            </div>
                            <div>
                                <label class="form-label">Take Profit:</label>
                                <input type="number" name="profit" value="32100" class="form-control">
                            </div>
                        </div>

                        <div>
                            <label class="form-label">Duration:</label>
                            <select class="form-control" name="duration">
                                <option value="2">2 minutes</option>
                                <option value="5">5 minutes</option>
                                <option value="10">10 minutes</option>
                            </select>
                        </div>

                        <button class="w-full btn btn-primary py-3 rounded-lg font-medium mt-4" type="submit" id="submitTrade">
                            Place Trade
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Trades Section -->
    <div class="dashboard-card">
        <div class="card-header">
            <div class="flex justify-between items-center">
                <h3 class="text-heading">Trade History</h3>
                <div class="flex space-x-2">
                    <button class="px-4 py-2 text-sm bg-primary text-white rounded-md font-medium active-tab-btn" id="openTradesBtn">Open</button>
                    <button class="px-4 py-2 text-sm text-gray-400 hover:text-gray-100 bg-gray-800 rounded-md font-medium inactive-tab-btn" id="closedTradesBtn">Completed</button>
                </div>
            </div>
        </div>

        <div class="card-body p-0">
            <!-- Open Trades Table -->
            <div id="openTradesSection">
                @if($userAssets->where('status', 'open')->isEmpty())
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="ri-exchange-funds-line"></i>
                        </div>
                        <p class="empty-state-text">No open trades yet.</p>
                        <button class="btn btn-primary inline-flex items-center" onclick="document.getElementById('tradeForm').scrollIntoView()">
                            <i class="ri-add-line mr-1"></i> Place a Trade
                        </button>
                    </div>
                @else
                    <div class="overflow-x-auto">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Asset</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Loss/Profit</th>
                                    <th>Action</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userAssets->where('status', 'open') as $trade)
                                <tr>
                                    <td>
                                        @php
                                            $symbollowcase = strtolower($trade->assets);
                                            $icon = $trade->assets;
                                            $icon2 = strtolower(substr($trade->assets, 0, 2));
                                            $iconSrc = '';

                                            if ($trade->trade_type == 'Crypto') {
                                                $iconSrc = "https://raw.githubusercontent.com/spothq/cryptocurrency-icons/refs/heads/master/svg/color/{$symbollowcase}.svg";
                                            } elseif ($trade->trade_type == 'Stocks') {
                                                $iconSrc = "https://cdn.jsdelivr.net/gh/ahmeterenodaci/Nasdaq-Stock-Exchange-including-Symbols-and-Logos/logos/_{$icon}.png";
                                            } elseif ($trade->trade_type == 'Forex') {
                                                $iconSrc = "https://flagcdn.com/36x27/{$icon2}.png";
                                            }
                                        @endphp
                                        <div class="flex items-center">
                                            <img class="w-6 h-6 rounded-full mr-2" src="{{ $iconSrc }}" alt="{{ $trade->assets }}" onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/0/381.png'">
                                            <span>{{ $trade->assets }}</span>
                                        </div>
                                    </td>
                                    <td>{{ $trade->trade_type }}</td>
                                    <td>${{ number_format($trade->amount, 2) }}</td>
                                    <td>
                                        <div class="flex flex-col">
                                            <span class="text-success">${{ $trade->profit }}</span>
                                            <span class="text-danger">${{ $trade->loss }}</span>
                                        </div>
                                    </td>
                                    <td>
                                        @if ($trade->action == 'buy')
                                            <span class="badge badge-success">Buy</span>
                                        @else
                                            <span class="badge badge-danger">Sell</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if ($trade->status == 'open')
                                            <span class="badge badge-success">Open</span>
                                        @else
                                            <span class="badge badge-danger">Closed</span>
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>

            <!-- Closed Trades Table -->
            <div id="closedTradesSection" class="hidden">
                @if($userAssets->where('status', 'complete')->isEmpty())
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="ri-exchange-funds-line"></i>
                        </div>
                        <p class="empty-state-text">No completed trades yet.</p>
                    </div>
                @else
                    <div class="overflow-x-auto">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Asset</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Loss/Profit</th>
                                    <th>Action</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($userAssets->where('status', 'complete') as $trade)
                                <tr>
                                    <td>
                                        @php
                                            $symbollowcase = strtolower($trade->assets);
                                            $icon = $trade->assets;
                                            $icon2 = strtolower(substr($trade->assets, 0, 2));
                                            $iconSrc = '';

                                            if ($trade->trade_type == 'Crypto') {
                                                $iconSrc = "https://raw.githubusercontent.com/spothq/cryptocurrency-icons/refs/heads/master/svg/color/{$symbollowcase}.svg";
                                            } elseif ($trade->trade_type == 'Stocks') {
                                                $iconSrc = "https://cdn.jsdelivr.net/gh/ahmeterenodaci/Nasdaq-Stock-Exchange-including-Symbols-and-Logos/logos/_{$icon}.png";
                                            } elseif ($trade->trade_type == 'Forex') {
                                                $iconSrc = "https://flagcdn.com/36x27/{$icon2}.png";
                                            }
                                        @endphp
                                        <div class="flex items-center">
                                            <img class="w-6 h-6 rounded-full mr-2" src="{{ $iconSrc }}" alt="{{ $trade->assets }}" onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/0/381.png'">
                                            <span>{{ $trade->assets }}</span>
                                        </div>
                                    </td>
                                    <td>{{ $trade->trade_type }}</td>
                                    <td>${{ number_format($trade->amount, 2) }}</td>
                                    <td>
                                        <div class="flex flex-col">
                                            <span class="text-success">${{ $trade->profit }}</span>
                                            <span class="text-danger">${{ $trade->loss }}</span>
                                        </div>
                                    </td>
                                    <td>
                                        @if ($trade->action == 'buy')
                                            <span class="badge badge-success">Buy</span>
                                        @else
                                            <span class="badge badge-danger">Sell</span>
                                        @endif
                                    </td>
                                    <td>
                                        <span class="badge badge-success">Completed</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Buy Crypto Modal -->
<div class="modal-overlay" id="buyCryptoModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="text-heading">Buy Cryptocurrency</h3>
            <button onclick="closeModal('buyCryptoModal')" class="modal-close">
                ✖
            </button>
        </div>

        <div class="modal-body">
            <form action="{{ route('user.crypto.buy.store') }}" method="POST" class="space-y-4">
                @csrf
                <input type="hidden" name="type" value="buy_crypto">

                <div>
                    <label for="buy_fiatAmount" class="form-label">Amount to Spend (USD)</label>
                    <input type="number" id="buy_fiatAmount" name="fiat_amount" step="0.01" min="0"
                        class="form-control"
                        placeholder="Enter amount in USD" required>
                </div>

                <div>
                    <label for="buy_cryptoAmount" class="form-label">You will receive</label>
                    <div class="flex items-center gap-2">
                        <input type="text" id="buy_cryptoAmount" name="crypto_amount" readonly
                            class="form-control bg-gray-50">
                        <span id="buy_cryptoSymbol" class="text-heading"></span>
                    </div>
                </div>

                <div>
                    <label for="buy_cryptoSelect" class="form-label">Select Cryptocurrency</label>
                    <div class="relative flex items-center bg-gray-50 rounded-lg border border-gray-300">
                        <img id="buy_cryptoIcon" src="" class="w-6 h-6 ml-3" alt="Crypto Icon">
                        <select id="buy_cryptoSelect" name="currency" class="w-full py-2 px-3 pl-12 bg-transparent text-gray-900 rounded-lg focus:ring-1 focus:ring-blue-500 focus:outline-none" required>
                            @foreach($currencies as $crypto)
                                <option value="{{ $crypto->symbol }}" data-icon="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/svg/color/{{ strtolower($crypto->symbol) }}.svg">
                                    {{ $crypto->name }} ({{ $crypto->symbol }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <button type="submit" class="w-full btn btn-success py-3 rounded-lg mt-4">
                    Buy Crypto
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Sell Crypto Modal -->
<div class="modal-overlay" id="sellCryptoModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="text-heading">Sell Cryptocurrency</h3>
            <button onclick="closeModal('sellCryptoModal')" class="modal-close">
                ✖
            </button>
        </div>

        <div class="modal-body">
            <form action="{{ route('user.crypto.sell.store') }}" method="POST" class="space-y-4">
                @csrf
                <input type="hidden" name="type" value="sell_crypto">

                <div>
                    <label for="sell_cryptoAmount" class="form-label">Amount to Sell</label>
                    <div class="flex items-center gap-2">
                        <input type="number" id="sell_cryptoAmount" name="crypto_amount" step="0.00000001" min="0"
                            class="form-control"
                            placeholder="Enter crypto amount" required>
                        <span id="sell_cryptoSymbol" class="text-heading"></span>
                    </div>
                </div>

                <div>
                    <label for="sell_fiatAmount" class="form-label">You will receive (USD)</label>
                    <input type="text" id="sell_fiatAmount" name="fiat_amount" readonly
                        class="form-control bg-gray-50">
                </div>

                <div>
                    <label for="sell_cryptoSelect" class="form-label">Select Cryptocurrency</label>
                    <div class="relative flex items-center bg-gray-50 rounded-lg border border-gray-300">
                        <img id="sell_cryptoIcon" src="" class="w-6 h-6 ml-3" alt="Crypto Icon">
                        <select id="sell_cryptoSelect" name="currency" class="w-full py-2 px-3 pl-12 bg-transparent text-gray-900 rounded-lg focus:ring-1 focus:ring-blue-500 focus:outline-none" required>
                            @foreach($currencies as $crypto)
                                <option value="{{ $crypto->symbol }}" data-icon="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/svg/color/{{ strtolower($crypto->symbol) }}.svg">
                                    {{ $crypto->name }} ({{ $crypto->symbol }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <button type="submit" class="w-full btn btn-danger py-3 rounded-lg mt-4">
                    Sell Crypto
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Fiat to Crypto Modal -->
<div class="modal-overlay" id="fiatToCryptoModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="text-heading">Convert Fiat to Crypto</h3>
            <button onclick="closeModal('fiatToCryptoModal')" class="modal-close">
                ✖
            </button>
        </div>

        <div class="modal-body">
            <form action="{{ route('user.crypto.deposit.store') }}" method="POST" class="space-y-4">
                @csrf
                <input type="hidden" name="type" value="fiat_to_crypto">

                <div>
                    <label for="f2c_fiatAmount" class="form-label">Fiat Amount (USD)</label>
                    <input type="number" id="f2c_fiatAmount" name="fiat_amount" step="0.01" min="0"
                        class="form-control"
                        placeholder="Enter amount in USD" required>
                </div>

                <div>
                    <label for="f2c_cryptoAmount" class="form-label">You will receive</label>
                    <div class="flex items-center gap-2">
                        <input type="text" id="f2c_cryptoAmount" name="crypto_amount" readonly
                            class="form-control bg-gray-50">
                        <span id="f2c_cryptoSymbol" class="text-heading"></span>
                    </div>
                </div>

                <div>
                    <label for="f2c_cryptoSelect" class="form-label">Select Cryptocurrency</label>
                    <div class="relative flex items-center bg-gray-50 rounded-lg border border-gray-300">
                        <img id="f2c_cryptoIcon" src="" class="w-6 h-6 ml-3" alt="Crypto Icon">
                        <select id="f2c_cryptoSelect" name="currency" class="w-full py-2 px-3 pl-12 bg-transparent text-gray-900 rounded-lg focus:ring-1 focus:ring-blue-500 focus:outline-none" required>
                            @foreach($currencies as $crypto)
                                <option value="{{ $crypto->symbol }}" data-icon="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/svg/color/{{ strtolower($crypto->symbol) }}.svg">
                                    {{ $crypto->name }} ({{ $crypto->symbol }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <button type="submit" class="w-full btn btn-primary py-3 rounded-lg mt-4">
                    Convert to Crypto
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Crypto to Fiat Modal -->
<div class="modal-overlay" id="cryptoToFiatModal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="text-heading">Convert Crypto to Fiat</h3>
            <button onclick="closeModal('cryptoToFiatModal')" class="modal-close">
                ✖
            </button>
        </div>

        <div class="modal-body">
            <form action="{{ route('user.crypto.deposit.store') }}" method="POST" class="space-y-4">
                @csrf
                <input type="hidden" name="type" value="crypto_to_fiat">

                <div>
                    <label for="c2f_cryptoSelect" class="form-label">Select Cryptocurrency</label>
                    <div class="relative flex items-center bg-gray-50 rounded-lg border border-gray-300">
                        <img id="c2f_cryptoIcon" src="" class="w-6 h-6 ml-3" alt="Crypto Icon">
                        <select id="c2f_cryptoSelect" name="currency" class="w-full py-2 px-3 pl-12 bg-transparent text-gray-900 rounded-lg focus:ring-1 focus:ring-blue-500 focus:outline-none" required>
                            @foreach($currencies as $crypto)
                                <option value="{{ $crypto->symbol }}" data-icon="https://raw.githubusercontent.com/spothq/cryptocurrency-icons/master/svg/color/{{ strtolower($crypto->symbol) }}.svg">
                                    {{ $crypto->name }} ({{ $crypto->symbol }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div>
                    <label for="c2f_cryptoAmount" class="form-label">Crypto Amount</label>
                    <input type="number" id="c2f_cryptoAmount" name="crypto_amount" step="0.00000001" min="0"
                        class="form-control"
                        placeholder="Enter crypto amount" required>
                </div>

                <div>
                    <label for="c2f_fiatAmount" class="form-label">You will receive (USD)</label>
                    <input type="text" id="c2f_fiatAmount" name="fiat_amount"
                        class="form-control bg-gray-50" readonly>
                </div>

                <button type="submit" class="w-full btn btn-info py-3 rounded-lg mt-4">
                    Convert to USD
                </button>
            </form>
        </div>
    </div>
</div>

<style>
    /* Chart Type Button Styles */
    .chart-type-btn {
        padding: 0.5rem 1rem;
        border-radius: 6px;
        font-size: 0.875rem;
        font-weight: 500;
        transition: all 0.2s ease;
        border: 1px solid var(--card-border);
        background-color: var(--dark);
        color: var(--gray);
        cursor: pointer;
    }

    .chart-type-btn.active {
        background-color: var(--primary);
        color: var(--white);
        border-color: var(--primary);
    }

    .chart-type-btn:hover:not(.active) {
        background-color: var(--gray-light);
        color: var(--text-primary);
    }

    /* Chart Container Styles */
    .chart-container {
        display: none;
        height: 100%;
        width: 100%;
    }

    .chart-container.active {
        display: block;
    }
</style>

<script>
    // Enhanced JavaScript functionality

    // Global variables
    let stocksData = [];
    let forexData = [];
    let cryptoData = [];

    // Modal functions
    function openModal(id) {
        document.getElementById(id).classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeModal(id) {
        document.getElementById(id).classList.remove('active');
        document.body.style.overflow = '';
    }

    // Chart type switching
    function switchChartType(type) {
        // Update button states
        document.querySelectorAll('.chart-type-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`.chart-type-btn[data-type="${type}"]`).classList.add('active');

        // Update chart visibility
        document.querySelectorAll('.chart-container').forEach(container => {
            container.classList.remove('active');
        });
        document.getElementById(`${type}-chart`).classList.add('active');
    }

    // Enhanced asset dropdown functionality
    function updateAssetDropdown() {
        const assetType = document.getElementById('assetType').value;
        const assetList = document.getElementById('assetList');
        const selectedIcon = document.getElementById('selectedIcon');
        const selectedSymbol = document.getElementById('selectedSymbol');
        const selectedAssetSymbol = document.getElementById('selectedAssetSymbol');

        // Clear existing assets
        assetList.innerHTML = '';

        let assets = [];
        let iconBaseUrl = '';

        if (assetType === 'crypto') {
            // Use crypto data
            assets = cryptoData.length ? cryptoData : [
                { symbol: 'BTC', name: 'Bitcoin' },
                { symbol: 'ETH', name: 'Ethereum' },
                { symbol: 'USDT', name: 'Tether' },
                { symbol: 'BNB', name: 'Binance Coin' }
            ];
            iconBaseUrl = 'https://raw.githubusercontent.com/spothq/cryptocurrency-icons/refs/heads/master/svg/color/';
        } else if (assetType === 'stock') {
            // Use stock data
            assets = stocksData.length ? stocksData : [
                { symbol: 'AAPL', name: 'Apple Inc.' },
                { symbol: 'GOOGL', name: 'Alphabet Inc.' },
                { symbol: 'MSFT', name: 'Microsoft Corporation' },
                { symbol: 'TSLA', name: 'Tesla Inc.' }
            ];
        } else if (assetType === 'fiat') {
            // Use forex data
            assets = forexData.length ? forexData : [
                { symbol: 'EURUSD', name: 'Euro to USD' },
                { symbol: 'GBPUSD', name: 'British Pound to USD' },
                { symbol: 'USDJPY', name: 'USD to Japanese Yen' },
                { symbol: 'AUDUSD', name: 'Australian Dollar to USD' }
            ];
        }

        // Populate asset list
        assets.forEach(asset => {
            let iconSrc = '';

            if (assetType === 'crypto') {
                iconSrc = iconBaseUrl + asset.symbol.toLowerCase() + '.svg';
            } else if (assetType === 'stock') {
                iconSrc = `https://cdn.jsdelivr.net/gh/ahmeterenodaci/Nasdaq-Stock-Exchange-including-Symbols-and-Logos/logos/_${asset.symbol}.png`;
            } else if (assetType === 'fiat') {
                const currencyCode = asset.symbol.substring(0, 2).toLowerCase();
                iconSrc = `https://flagcdn.com/36x27/${currencyCode}.png`;
            }

            const listItem = document.createElement('li');
            listItem.classList.add('asset-item', 'flex', 'items-center', 'justify-between', 'px-4', 'py-2', 'hover:bg-gray-700', 'cursor-pointer');
            listItem.setAttribute('data-symbol', asset.symbol);
            listItem.setAttribute('data-name', asset.name);
            listItem.setAttribute('data-icon', iconSrc);

            listItem.innerHTML = `
                <div class="flex items-center space-x-2">
                    <img src="${iconSrc}" alt="${asset.symbol}" class="w-4 h-4" onerror="this.onerror=null; this.src='https://cdn-icons-png.flaticon.com/512/0/381.png'">
                    <span class="text-gray-100">${asset.symbol.toUpperCase()}</span>
                </div>
                <span class="text-gray-400 text-xs">${assetType}</span>
            `;

            assetList.appendChild(listItem);

            // Add click listener
            listItem.addEventListener('click', () => {
                selectedIcon.src = iconSrc;
                selectedSymbol.textContent = asset.symbol;
                selectedAssetSymbol.value = asset.symbol;

                // Update asset price and balance
                updateAssetPrice(asset.symbol, assetType);
                updateAssetBalance(asset.symbol, assetType);

                // Close dropdown
                document.getElementById('dropdownMenu').classList.add('hidden');
            });
        });

        // Set default selection
        if (assets.length > 0) {
            const defaultAsset = assets[0];
            let defaultIconSrc = '';

            if (assetType === 'crypto') {
                defaultIconSrc = iconBaseUrl + defaultAsset.symbol.toLowerCase() + '.svg';
            } else if (assetType === 'stock') {
                defaultIconSrc = `https://cdn.jsdelivr.net/gh/ahmeterenodaci/Nasdaq-Stock-Exchange-including-Symbols-and-Logos/logos/_${defaultAsset.symbol}.png`;
            } else if (assetType === 'fiat') {
                const currencyCode = defaultAsset.symbol.substring(0, 2).toLowerCase();
                defaultIconSrc = `https://flagcdn.com/36x27/${currencyCode}.png`;
            }

            selectedIcon.src = defaultIconSrc;
            selectedSymbol.textContent = defaultAsset.symbol;
            selectedAssetSymbol.value = defaultAsset.symbol;

            updateAssetPrice(defaultAsset.symbol, assetType);
            updateAssetBalance(defaultAsset.symbol, assetType);
        }
    }

    // Update asset price
    function updateAssetPrice(symbol, type) {
        const currentAssetPrice = document.getElementById('currentAssetPrice');

        if (type === 'crypto') {
            fetch(`https://min-api.cryptocompare.com/data/price?fsym=${symbol}&tsyms=USD`)
                .then(response => response.json())
                .then(data => {
                    const price = data.USD;
                    if (price) {
                        currentAssetPrice.textContent = `${price.toFixed(2)}`;
                    }
                })
                .catch(error => {
                    console.error('Error fetching crypto price:', error);
                    currentAssetPrice.textContent = '$0.00';
                });
        } else if (type === 'stock') {
            // Mock stock prices - in production, use a real stock API
            const mockStockPrices = {
                'AAPL': 150.25,
                'GOOGL': 2800.50,
                'MSFT': 330.75,
                'TSLA': 250.00
            };
            const price = mockStockPrices[symbol] || 100.00;
            currentAssetPrice.textContent = `${price.toFixed(2)}`;
        } else if (type === 'fiat') {
            // Mock forex rates - in production, use a real forex API
            const mockForexRates = {
                'EURUSD': 1.0850,
                'GBPUSD': 1.2650,
                'USDJPY': 0.0067,
                'AUDUSD': 0.6750
            };
            const rate = mockForexRates[symbol] || 1.0000;
            currentAssetPrice.textContent = `${rate.toFixed(4)}`;
        }
    }

    // Update asset balance
    function updateAssetBalance(symbol, type) {
        const assetBalance = document.getElementById('assetBalance');

        // Mock balances - in production, fetch from your database
        const mockBalances = {
            'BTC': 0.00125,
            'ETH': 0.045,
            'AAPL': 5,
            'GOOGL': 2,
            'EURUSD': 1000,
            'GBPUSD': 800
        };

        const balance = mockBalances[symbol] || 0.00;
        assetBalance.textContent = `${balance} ${symbol}`;
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        if (event.target.classList.contains('modal-overlay')) {
            closeModal(event.target.id);
        }
    }

    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tab-nav-item');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach((button) => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });

    // Trade table switching
    document.getElementById('openTradesBtn').addEventListener('click', function() {
        this.classList.add('active-tab-btn');
        this.classList.remove('inactive-tab-btn');
        document.getElementById('closedTradesBtn').classList.remove('active-tab-btn');
        document.getElementById('closedTradesBtn').classList.add('inactive-tab-btn');
        document.getElementById('openTradesSection').classList.remove('hidden');
        document.getElementById('closedTradesSection').classList.add('hidden');
    });

    document.getElementById('closedTradesBtn').addEventListener('click', function() {
        this.classList.add('active-tab-btn');
        this.classList.remove('inactive-tab-btn');
        document.getElementById('openTradesBtn').classList.remove('active-tab-btn');
        document.getElementById('openTradesBtn').classList.add('inactive-tab-btn');
        document.getElementById('closedTradesSection').classList.remove('hidden');
        document.getElementById('openTradesSection').classList.add('hidden');
    });

    // Asset dropdown functionality
    document.addEventListener('DOMContentLoaded', function() {
        const dropdownButton = document.getElementById('dropdownButton');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const assetSearch = document.getElementById('assetSearch');

        // Toggle dropdown
        dropdownButton.addEventListener('click', () => {
            dropdownMenu.classList.toggle('hidden');
            if (!dropdownMenu.classList.contains('hidden')) {
                assetSearch.focus();
            }
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!dropdownMenu.contains(event.target) && !dropdownButton.contains(event.target)) {
                dropdownMenu.classList.add('hidden');
            }
        });

        // Search functionality
        assetSearch.addEventListener('input', function(e) {
            const query = e.target.value.toLowerCase();
            document.querySelectorAll('.asset-item').forEach((item) => {
                const text = item.textContent.toLowerCase();
                item.style.display = text.includes(query) ? 'flex' : 'none';
            });
        });

        // Initialize asset dropdown
        updateAssetDropdown();

        // Load external data
        loadExternalData();
    });

    // Load external data (stocks, forex)
    function loadExternalData() {
        // Load stock data
        fetch('https://tradededpro.com/app/assets/global/jsons/stock.json')
            .then(response => response.json())
            .then(data => {
                stocksData = data;
            })
            .catch(error => console.error('Error loading stock data:', error));

        // Load forex data
        fetch('https://tradededpro.com/app/assets/global/jsons/forex.json')
            .then(response => response.json())
            .then(data => {
                forexData = Object.entries(data.usd).map(([symbol, rate]) => ({
                    symbol: symbol.toUpperCase(),
                    name: symbol.toUpperCase(),
                    rate: rate
                }));
            })
            .catch(error => console.error('Error loading forex data:', error));
    }

    // Modal crypto conversion functionality
    document.addEventListener('DOMContentLoaded', function() {
        // Buy Crypto Modal
        const buy_fiatAmount = document.getElementById('buy_fiatAmount');
        const buy_cryptoAmount = document.getElementById('buy_cryptoAmount');
        const buy_cryptoSelect = document.getElementById('buy_cryptoSelect');
        const buy_cryptoIcon = document.getElementById('buy_cryptoIcon');
        const buy_cryptoSymbol = document.getElementById('buy_cryptoSymbol');

        function updateBuyConversion() {
            const fiatAmount = parseFloat(buy_fiatAmount.value) || 0;
            const cryptoSymbol = buy_cryptoSelect.value;

            if (fiatAmount <= 0 || !cryptoSymbol) {
                buy_cryptoAmount.value = '';
                return;
            }

            fetch(`https://min-api.cryptocompare.com/data/price?fsym=${cryptoSymbol}&tsyms=USD`)
                .then(response => response.json())
                .then(data => {
                    const price = data.USD;
                    if (price && price > 0) {
                        const cryptoAmount = fiatAmount / price;
                        buy_cryptoAmount.value = cryptoAmount.toFixed(8);
                        buy_cryptoSymbol.textContent = cryptoSymbol;
                    }
                })
                .catch(error => {
                    console.error('Error fetching crypto price:', error);
                    buy_cryptoAmount.value = '';
                });
        }

        buy_fiatAmount.addEventListener('input', updateBuyConversion);
        buy_cryptoSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            buy_cryptoIcon.src = selectedOption.getAttribute('data-icon');
            updateBuyConversion();
        });

        // Sell Crypto Modal
        const sell_cryptoAmount = document.getElementById('sell_cryptoAmount');
        const sell_fiatAmount = document.getElementById('sell_fiatAmount');
        const sell_cryptoSelect = document.getElementById('sell_cryptoSelect');
        const sell_cryptoIcon = document.getElementById('sell_cryptoIcon');
        const sell_cryptoSymbol = document.getElementById('sell_cryptoSymbol');

        function updateSellConversion() {
            const cryptoAmount = parseFloat(sell_cryptoAmount.value) || 0;
            const cryptoSymbol = sell_cryptoSelect.value;

            if (cryptoAmount <= 0 || !cryptoSymbol) {
                sell_fiatAmount.value = '';
                return;
            }

            fetch(`https://min-api.cryptocompare.com/data/price?fsym=${cryptoSymbol}&tsyms=USD`)
                .then(response => response.json())
                .then(data => {
                    const price = data.USD;
                    if (price && price > 0) {
                        const fiatAmount = cryptoAmount * price;
                        sell_fiatAmount.value = `${fiatAmount.toFixed(2)}`;
                        sell_cryptoSymbol.textContent = cryptoSymbol;
                    }
                })
                .catch(error => {
                    console.error('Error fetching crypto price:', error);
                    sell_fiatAmount.value = '';
                });
        }

        sell_cryptoAmount.addEventListener('input', updateSellConversion);
        sell_cryptoSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            sell_cryptoIcon.src = selectedOption.getAttribute('data-icon');
            updateSellConversion();
        });

        // Fiat to Crypto Modal
        const f2c_fiatAmount = document.getElementById('f2c_fiatAmount');
        const f2c_cryptoAmount = document.getElementById('f2c_cryptoAmount');
        const f2c_cryptoSelect = document.getElementById('f2c_cryptoSelect');
        const f2c_cryptoIcon = document.getElementById('f2c_cryptoIcon');
        const f2c_cryptoSymbol = document.getElementById('f2c_cryptoSymbol');

        function updateF2CConversion() {
            const fiatAmount = parseFloat(f2c_fiatAmount.value) || 0;
            const cryptoSymbol = f2c_cryptoSelect.value;

            if (fiatAmount <= 0 || !cryptoSymbol) {
                f2c_cryptoAmount.value = '';
                return;
            }

            fetch(`https://min-api.cryptocompare.com/data/price?fsym=${cryptoSymbol}&tsyms=USD`)
                .then(response => response.json())
                .then(data => {
                    const price = data.USD;
                    if (price && price > 0) {
                        const cryptoAmount = fiatAmount / price;
                        f2c_cryptoAmount.value = cryptoAmount.toFixed(8);
                        f2c_cryptoSymbol.textContent = cryptoSymbol;
                    }
                })
                .catch(error => {
                    console.error('Error fetching crypto price:', error);
                    f2c_cryptoAmount.value = '';
                });
        }

        f2c_fiatAmount.addEventListener('input', updateF2CConversion);
        f2c_cryptoSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            f2c_cryptoIcon.src = selectedOption.getAttribute('data-icon');
            updateF2CConversion();
        });

        // Crypto to Fiat Modal
        const c2f_cryptoAmount = document.getElementById('c2f_cryptoAmount');
        const c2f_fiatAmount = document.getElementById('c2f_fiatAmount');
        const c2f_cryptoSelect = document.getElementById('c2f_cryptoSelect');
        const c2f_cryptoIcon = document.getElementById('c2f_cryptoIcon');

        function updateC2FConversion() {
            const cryptoAmount = parseFloat(c2f_cryptoAmount.value) || 0;
            const cryptoSymbol = c2f_cryptoSelect.value;

            if (cryptoAmount <= 0 || !cryptoSymbol) {
                c2f_fiatAmount.value = '';
                return;
            }

            fetch(`https://min-api.cryptocompare.com/data/price?fsym=${cryptoSymbol}&tsyms=USD`)
                .then(response => response.json())
                .then(data => {
                    const price = data.USD;
                    if (price && price > 0) {
                        const fiatAmount = cryptoAmount * price;
                        c2f_fiatAmount.value = `${fiatAmount.toFixed(2)}`;
                    }
                })
                .catch(error => {
                    console.error('Error fetching crypto price:', error);
                    c2f_fiatAmount.value = '';
                });
        }

        c2f_cryptoAmount.addEventListener('input', updateC2FConversion);
        c2f_cryptoSelect.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            c2f_cryptoIcon.src = selectedOption.getAttribute('data-icon');
            updateC2FConversion();
        });

        // Initialize all crypto selects
        if (buy_cryptoSelect.value) {
            buy_cryptoIcon.src = buy_cryptoSelect.options[buy_cryptoSelect.selectedIndex].getAttribute('data-icon');
        }
        if (sell_cryptoSelect.value) {
            sell_cryptoIcon.src = sell_cryptoSelect.options[sell_cryptoSelect.selectedIndex].getAttribute('data-icon');
        }
        if (f2c_cryptoSelect.value) {
            f2c_cryptoIcon.src = f2c_cryptoSelect.options[f2c_cryptoSelect.selectedIndex].getAttribute('data-icon');
        }
        if (c2f_cryptoSelect.value) {
            c2f_cryptoIcon.src = c2f_cryptoSelect.options[c2f_cryptoSelect.selectedIndex].getAttribute('data-icon');
        }
    });

    // Signal strength update
    function updateSignalStrength(strength) {
        const bars = document.querySelectorAll('.signal-bar');
        const activeCount = Math.ceil((strength / 100) * bars.length);

        bars.forEach((bar, index) => {
            if (index < activeCount) {
                if (index < 1) {
                    bar.style.backgroundColor = 'var(--danger)';
                } else if (index < 3) {
                    bar.style.backgroundColor = 'var(--warning)';
                } else {
                    bar.style.backgroundColor = 'var(--success)';
                }
                bar.classList.remove('bg-gray-700');
            } else {
                bar.style.backgroundColor = '';
                bar.classList.add('bg-gray-700');
            }
        });

        const strengthDisplay = document.querySelector('.signal-strength-value');
        if (strengthDisplay) {
            strengthDisplay.textContent = `${strength}%`;
            strengthDisplay.classList.toggle('text-success', strength > 50);
            strengthDisplay.classList.toggle('text-danger', strength <= 50);
        }
    }

    // Update signal strength every 5 seconds
    setInterval(() => {
        const newStrength = Math.floor(Math.random() * 100);
        updateSignalStrength(newStrength);
    }, 5000);

    // Form submission with validation
    document.getElementById('tradeForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const form = this;
        const submitButton = document.getElementById('submitTrade');
        const originalButtonText = submitButton.textContent;

        // Show loading state
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="ri-loader-4-line animate-spin mr-1"></i> Processing...';

        // Perform form validation
        const amount = parseFloat(form.amount.value);
        const balance = parseFloat("{{ auth()->user()->balance }}");

        if (isNaN(amount) || amount <= 0) {
            alert('Please enter a valid amount');
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
            return;
        }

        if (amount > balance) {
            alert('Insufficient balance for this trade');
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
            return;
        }

        // If validation passes, submit the form
        setTimeout(() => {
            form.submit();
        }, 1000);
    });
</script>
@endsection
